export const SIGNUP_URL = 'auth-api/userSignUp';
export const ACTIVEMAIL_URL = 'auth-api/activeAccount';
export const LOGIN_URL = 'auth-api/Login';
export const LOGOUT_URL = '';
export const SETTING_URL = 'setting-api/setting';
export const CITY_URL = 'setting-api/city';
export const HOUSE_RULE_URL = 'house-api/house';
export const FORGET_PASSWORD_URL = "/auth-api/forgotPassword";
export const SET_PASSWORD_URL = "/auth-api/updatePassword";
export const CHANGEPASSWORD_URL = 'user-api/changePassword';
export const CMS_URL = 'cms-api/cms';
export const CONTACTUS_URL = 'contactUs-api/contactUs';
export const PROFILEPICTURE_URL = 'user-api/profilePicture';
export const ROOMPICTURE_URL = 'auth-api/roomPicture';
export const EDITPROFILE_URL = 'auth-api/updateProfile';
export const VIEWPROFILE_URL = 'auth-api/profileDetails';
export const USERLIST_URL = 'auth-api/user';
export const EDITLANDLORD_URL = 'landlord-api/landlord'
export const ROOM_URL = 'landlord-api/room'
export const USER_URL = 'user-api';
export const LANDLORD_URL = 'landlord-api'
export const AMINITIES_URL = 'setting-api/aminities';
export const FAV_URL = 'favorite-api/fav'
export const FAVROOM_URL = 'favorite-api/favRoomList';
export const SOCIALLOGIN_URL = 'auth-api/socialLogin';
export const ADD_AGENT_URL = 'agent-api/AddAgentProperty';
export const LIST_AGENT_URL = 'agent-api/agent';
export const LIST_AGENTT_URL = 'agent-api/agentt';
export const UPDATE_AGENTT_URL = 'agent-api/updateAgentProperty';
export const ADD_PROPERTY = "/agent-api/agentProperty";




