export const LOGIN_URL = 'auth-api/userLogin';
export const LOGOUT_URL = '';
export const SETTING_URL = 'setting-api/setting';
export const FORGET_PASSWORD_URL = "/auth-api/web/forgotPassword";
export const SET_PASSWORD_URL = "/auth-api/web/updatePassword";
export const USER_URL = 'auth-api/userSignUp';
export const ACTIVEMAIL_URL = 'auth-api/activeAccount';
export const CMS_URL = 'cms-api/cms';
export const CHANGEPASSWORD_URL = 'auth-api/changePassword';
export const CONTACTUS_URL = 'contactUs-api/contactUs';
export const PROFILEPICTURE_URL = 'auth-api/profilePicture';
export const EDITPROFILE_URL = 'auth-api/updateProfile';
export const VIEWPROFILE_URL = 'auth-api/profileDetails';





