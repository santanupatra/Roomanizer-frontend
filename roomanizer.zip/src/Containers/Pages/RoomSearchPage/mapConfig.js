
// export const mapApiKey    = 'AIzaSyDDeMWe3wO5mhMCb-wyUC9UIYORSmKbROc';
export const mapApiKey    = 'AIzaSyA5LrPhIokuSBO5EgKEcfu859gog6fRF8w';
export const googleMapURL = "https://maps.googleapis.com/maps/api/js?key="+mapApiKey;  
export const defaultZoom  = 4.6;
export const defaultCenter  = { lat: 35.1495343, lng: -90.0489801 };
export const mapTypeId = "hybrid"
//export const getAllMarkerIcons = MapMarkerImgPath;
//export const getMarkerIcon = type => MapMarkerImgPath[type+'_marker_icon'];